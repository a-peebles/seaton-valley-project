package com.ncl.team20.seatonvalley.components.web;

import android.graphics.Bitmap;
import android.os.Handler;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;

import com.google.android.gms.maps.MapView;
import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.activities.ContactActivity;

/**
 * Created by Stelios-Ioannou on 26/03/2018.
 */

class SeatonWebClient extends WebViewClient {

    private final ProgressBar progressBar;
    private final int type;
    private boolean launched = false;
    private long timeToLoadForecast;

    public SeatonWebClient(ProgressBar m_progressBar, int m_type) {
        this.progressBar = m_progressBar;
        this.type = m_type;
    }

    @Override
    public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);
        timeToLoadForecast = System.currentTimeMillis() - timeToLoadForecast;

        if (type == 0 && !launched) {
            view.loadUrl("javascript:(function() { " +
                    "var post = document.querySelectorAll('.gdlr-item.gdlr-blog-full.gdlr-item-start-content');" +
                    "if (post.length) {post[0].id = 'post'};" +
                    "jQuery('body > :not(#post)').hide();" +
                    "jQuery('#post').appendTo('body');" +
                    "jQuery('.container').css('max-width', '2560px');" +
                    "document.body.style.backgroundColor = 'white';" +
                    "})()");
            view.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
            launched = true;
        } else if (type == 1 && !launched) {
            //Added 4 sec delay in order to give a chance for nested receiver to load in order to ensure that it will apply the style
            new Handler().postDelayed(() -> {
                if(timeToLoadForecast<200){
                    timeToLoadForecast=200;
                }
                view.loadUrl("javascript:(function() { " +
                        "$('body > :not(#widget)').hide();" +
                        "$('#widget').appendTo('body');" +
                        "var search = document.querySelectorAll('.row.search-cities');" +
                        "if (search.length) {search[0].id = 'search'};" +
                        "var element = document.getElementById('search');" +
                        "element.parentNode.removeChild(element);" +
                        "$('a').css({color: '#732772'});" +
                        "$('.widget__title').css({color: '#732772'});" +
                        "$('.weather-widget__link').css({color: '#732772'});" +
                        "$('.weather-forecast-list__day').css('background-color', '#732772');" +
                        "})()");
                view.setVisibility(View.VISIBLE);
                progressBar.setVisibility(View.GONE);
            }, timeToLoadForecast/2);
            launched = true;
        } else {
            view.setVisibility(View.VISIBLE);
            progressBar.setVisibility(View.GONE);
        }

    }

    @Override
    public void onPageStarted(WebView view, String url, Bitmap favicon) {
        timeToLoadForecast = System.currentTimeMillis();
        view.setVisibility(View.GONE);
        super.onPageStarted(view, url, favicon);
    }

}