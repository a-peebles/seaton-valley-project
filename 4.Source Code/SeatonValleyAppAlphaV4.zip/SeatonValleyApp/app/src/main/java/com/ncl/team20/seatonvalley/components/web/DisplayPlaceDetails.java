package com.ncl.team20.seatonvalley.components.web;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.NavigationView;
import android.support.v7.widget.Toolbar;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.ncl.team20.seatonvalley.ConnectionDetector;
import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.activities.PlacesActivity;
import com.ncl.team20.seatonvalley.components.basic.Connection;

public class DisplayPlaceDetails extends Connection implements OnMapReadyCallback {

    MapView mapView;
    private int currentPosition;
    private String title;

    private final ConnectionDetector detector = new ConnectionDetector(DisplayPlaceDetails.this);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);
        setContentView(R.layout.activity_place_details);


        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Intent i = getIntent();
        //noinspection ConstantConditions
        currentPosition = i.getExtras().getInt("itemPosition");
        title = PlacesActivity.mListPlace.getResults().get(currentPosition).getName();
        setTitle(title);

        NavigationView navigationView = findViewById(R.id.nav_view);

        navigationView.setNavigationItemSelectedListener(this);


        new Handler().postDelayed(() -> {
            MapView map_view = findViewById(R.id.map_place);
            map_view.onCreate(null);
            map_view.onResume();
            map_view.getMapAsync(DisplayPlaceDetails.this);
        }, 100);
    }


    //Creates the Google Map View for the Council Address.
    @Override
    public void onMapReady(GoogleMap googleMap) {

        //Council Address
        LatLng council_address = new LatLng(55.0729621, -1.5262413);
        //Creates a Camera Update
        CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(PlacesActivity.mListPlace.getResults().get(currentPosition).getGeometry().getLocation().getLatLng(), 18);
        //Moves to the Council Address view.
        googleMap.moveCamera(cameraUpdate);


        //Custom Color for the Marker
        final float marker_color = 338.0F;

        //Adds the Marker.
        googleMap.addMarker(new MarkerOptions()
                .position(PlacesActivity.mListPlace.getResults().get(currentPosition).getGeometry().getLocation().getLatLng())
                .title(title)
                .icon(BitmapDescriptorFactory.defaultMarker(marker_color))
        );
    }


    //Ovverides the onBackPressed that was defined in components,because this back button is not going directly on the home screen.
    @Override
    public void onBackPressed() {
        finish();
        overridePendingTransition(R.anim.anim_slide_in_right, R.anim.anim_slide_out_right);
    }

    //Enables Back-button,implements the correct implementation that is needed for this method.
    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }

}
