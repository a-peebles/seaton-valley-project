package com.ncl.team20.seatonvalley.data.places;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class LocationTest {
    @Test
    public void getLat() throws Exception {
    }

    @Test
    public void setLat() throws Exception {
    }

    @Test
    public void getLng() throws Exception {
    }

    @Test
    public void setLng() throws Exception {
    }

}