package com.ncl.team20.seatonvalley.data.places;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class PlaceTest {
    @Test
    public void getHtmlAttributions() throws Exception {
    }

    @Test
    public void setHtmlAttributions() throws Exception {
    }

    @Test
    public void getResults() throws Exception {
    }

    @Test
    public void setResults() throws Exception {
    }

    @Test
    public void getStatus() throws Exception {
    }

    @Test
    public void setStatus() throws Exception {
    }

}