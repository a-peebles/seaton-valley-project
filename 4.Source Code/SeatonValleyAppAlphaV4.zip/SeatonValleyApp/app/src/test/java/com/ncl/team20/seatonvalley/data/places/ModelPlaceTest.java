package com.ncl.team20.seatonvalley.data.places;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
class ModelPlaceTest {

}