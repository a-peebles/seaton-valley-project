package com.ncl.team20.seatonvalley.components;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class ConnectionTest {
    @Test
    public void onResume() throws Exception {
    }

    @Test
    public void onPause() throws Exception {
    }

}