package com.ncl.team20.seatonvalley.adapters;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class LocationsRecyclerViewAdapterTest {
    @Test
    public void onCreateViewHolder() throws Exception {
    }

    @Test
    public void onBindViewHolder() throws Exception {
    }

    @Test
    public void getItemCount() throws Exception {
    }

}