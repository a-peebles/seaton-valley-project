package com.ncl.team20.seatonvalley;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class DisplayPostDetailsTest {
    @Test
    public void onCreate() throws Exception {
    }

    @Test
    public void onBackPressed() throws Exception {
    }

    @Test
    public void onSupportNavigateUp() throws Exception {
    }

}