package com.ncl.team20.seatonvalley;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class WPPost {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("title")
    @Expose
    private Title title;

    @SerializedName("excerpt")
    @Expose
    private Excerpt excerpt;
    @SerializedName("link")
    @Expose
    private String link;


    public Integer getId() {
        return id;
    }


    public Title getTitle() {
        return title;
    }

    public Excerpt getExcerpt() {
        return excerpt;
    }

    public String getLink() {
        return link;
    }

}


class Excerpt {

    @SerializedName("rendered")
    @Expose
    private String rendered;

    public String getRendered() {
        return rendered;
    }

}


class Title {

    @SerializedName("rendered")
    @Expose
    private String rendered;

    public String getRendered() {
        return rendered;
    }

}


