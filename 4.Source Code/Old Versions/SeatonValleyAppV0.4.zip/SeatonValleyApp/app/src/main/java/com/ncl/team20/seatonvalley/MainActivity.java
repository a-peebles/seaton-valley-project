
package com.ncl.team20.seatonvalley;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.ncl.team20.seatonvalley.rest_api_reader.Model;
import com.ncl.team20.seatonvalley.rest_api_reader.RecyclerViewAdapter;
import com.ncl.team20.seatonvalley.rest_api_reader.RetrofitArrayApi;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.jsoup.Jsoup;

import java.util.ArrayList;
import java.util.List;

import okhttp3.Cache;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private ProgressBar progressBar;
    private ArrayList<Model> list;
    private RecyclerViewAdapter adapter;
    public static List<WPPost> mListPost;
    public static boolean active = false;
    private static boolean cached = false;
    private int minutesPassed = (int) System.currentTimeMillis();

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("Home");

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        final ImageButton btnNews = findViewById(R.id.btnNews);
        final ImageButton btnTwitter = findViewById(R.id.btnTwitter);
        final ImageButton btnEvents = findViewById(R.id.btnEvents);
        final ImageButton btnFind = findViewById(R.id.btnFind);
        final ImageButton btnContact = findViewById(R.id.btnContact);
        final ImageButton btnReport = findViewById(R.id.btnReport);
        final ImageButton btnCouncil = findViewById(R.id.btnCouncil);
        final ImageButton btnInfo = findViewById(R.id.btnInfo);
        final ImageButton btnSettings = findViewById(R.id.btnSettings);
        final LinearLayout carousel = findViewById(R.id.carousel);
        final LinearLayout weatherLayout = findViewById(R.id.weather);
        final TextView temperatureView = weatherLayout.findViewById(R.id.weather_temperature);
        final ImageView weatherIcon = carousel.findViewById(R.id.weather_icon);
        //latitude and longitude of centre point in Seaton Valley
        double longitude = -1.518362;
        double latitude = 55.084432;
        //key to access openweathermap api
        String API_KEY = "97517c7d1e1d037af35cd1fb72095a09";
        String query = "lat=" + latitude + "&lon=" + longitude + "&appid=" + API_KEY + "&units=metric";
        //creates a request for JSON data at point of latitude and longitude
        String BASE_URL = "http://api.openweathermap.org/data/2.5/weather?";
        final String[] weatherIconCode = new String[1];
        final String IMAGES_URL = "http://openweathermap.org/img/w/";

        RecyclerView recyclerView = findViewById(R.id.recycler_view_latest);
        progressBar = findViewById(R.id.progressbar);
        progressBar.setVisibility(View.GONE);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(mLayoutManager);

        list = new ArrayList<>();

        ConnectionDetector detector = new ConnectionDetector(MainActivity.this);

        if (detector.isInternetAvailable()) {

            progressBar.setVisibility(View.VISIBLE);
            getRetrofit();
            adapter = new RecyclerViewAdapter(list, MainActivity.this);
            recyclerView.setAdapter(adapter);

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, BASE_URL + query, null, new Response.Listener<JSONObject>() {
                /**
                 * runs if the JSON data is successfully retrieved
                 * @author Alex Peebles
                 * @param response data received from request
                 *
                 */
                @Override
                public void onResponse(JSONObject response) {


                    try {

                        JSONObject mainObject = response.getJSONObject("main");
                        JSONArray weatherArray = response.getJSONArray("weather");
                        JSONObject weatherObject = (JSONObject) weatherArray.get(0);
                        //sets the temp textView text to the current celsius temperature
                        temperatureView.setText(String.format("%s\u2103", mainObject.getDouble("temp")));
                        //retrieves a weather icon code that corresponds to an image
                        weatherIconCode[0] = weatherObject.getString("icon");
                        //initialise Piccasso API
                        Picasso picasso = Picasso.with(getApplicationContext());
                        //retrieves image from the url using the weather icon code and places it in an ImageView
                        picasso.load(String.format("%s%s.png", IMAGES_URL, weatherIconCode[0])).resize(100, 100).into(weatherIcon);


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                /**
                 * displays a toast if the JSON request encountered an error
                 * @param error error information
                 */
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), R.string.weather_error, Toast.LENGTH_LONG).show();
                }

            });
            Volley.newRequestQueue(getApplicationContext()).add(jsonObjectRequest);
        } else {
            getRetrofit();
            adapter = new RecyclerViewAdapter(list, MainActivity.this);
            recyclerView.setAdapter(adapter);
            this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }


        btnNews.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), NewsActivity.class);
            startActivity(intent);
        });
        btnTwitter.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), TwitterActivity.class);
            startActivity(intent);
        });
        btnEvents.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), EventsActivity.class);
            startActivity(intent);
        });
        btnFind.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), FindActivity.class);
            startActivity(intent);
        });
        btnContact.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), ContactActivity.class);
            startActivity(intent);
        });
        btnReport.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), ReportActivity.class);
            startActivity(intent);
        });
        btnCouncil.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), CouncilActivity.class);
            startActivity(intent);
        });
        btnInfo.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), InfoActivity.class);
            startActivity(intent);
        });
        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), SettingsActivity.class);
            startActivity(intent);
        });
    }

    private void getRetrofit() {


        EventsActivity.active = false;
        NewsActivity.active = false;
        MainActivity.active = true;
        String baseURL = "http://seatonvalleycommunitycouncil.gov.uk/";
        String request = "/wp-json/wp/v2/posts?per_page=3&categories=";
        String category = "16";

        int cacheSize = 10 * 1024 * 1024;
        Cache cacheLatestPost = new Cache(getCacheDir(), cacheSize);

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .cache(cacheLatestPost)
                .addInterceptor(chain -> {
                    okhttp3.Request request1 = chain.request();
                    ConnectionDetector detector = new ConnectionDetector(MainActivity.this);
                    boolean timeForNewCache = false;

                    if (((int) System.currentTimeMillis() - (int) System.currentTimeMillis() <= 600000)) {
                        timeForNewCache = true;
                    }

                    if (!detector.isInternetAvailable() || (timeForNewCache && cached)) {
                        progressBar.setVisibility(View.GONE);
                        minutesPassed = (int) System.currentTimeMillis();
                        int maxStale = 60 * 60 * 24 * 28; // tolerate 4-weeks stale \
                        request1 = request1
                                .newBuilder()
                                .header("Cache-Control", "public, only-if-cached, max-stale=" + maxStale)
                                .build();
                    }
                    return chain.proceed(request1);
                })
                .build();

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl(baseURL)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create());


        Retrofit retrofit = builder.build();

        RetrofitArrayApi service = retrofit.create(RetrofitArrayApi.class);
        Call<List<WPPost>> call = service.getPostInfo(baseURL + request + category);


        //noinspection NullableProblems,NullableProblems,NullableProblems,NullableProblems
        call.enqueue(new Callback<List<WPPost>>() {
            @Override
            public void onResponse(@SuppressWarnings("NullableProblems") Call<List<WPPost>> call, @SuppressWarnings("NullableProblems") retrofit2.Response<List<WPPost>> response) {
                cached = true;

                Log.e("mainactivity", " response " + response.body());
                mListPost = response.body();
                progressBar.setVisibility(View.GONE);
                //noinspection ConstantConditions
                for (int i = 0; i < response.body().size(); i++) {

                    //noinspection ConstantConditions,ConstantConditions
                    Log.e("main ", " title " + response.body().get(i).getTitle().getRendered() + "" +
                            response.body().get(i).getId());

                    //noinspection ConstantConditions
                    @SuppressWarnings("ConstantConditions") String title = response.body().get(i).getTitle().getRendered();
                    title = Jsoup.parse(title).text();

                    //noinspection ConstantConditions
                    @SuppressWarnings("ConstantConditions") String description = response.body().get(i).getExcerpt().getRendered();
                    description = description.replace("<p>", "");
                    description = description.replace("</p>", "");
                    description = description.replace("[&hellip;]", "");
                    description = description.replace("&nbsp;", "");
                    description = Jsoup.parse(description).text();


                    if (description.length() > 100) {
                        description = description.substring(0, 100) + "...";
                    }

                    list.add(new Model(title,
                            description
                    ));
                }
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onFailure(@SuppressWarnings("NullableProblems") Call<List<WPPost>> call, @SuppressWarnings("NullableProblems") Throwable t) {

            }
        });

    }


    @Override
    protected void onResume() {
        super.onResume();
        EventsActivity.active = false;
        NewsActivity.active = false;
        MainActivity.active = true;
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setCheckedItem(R.id.nav_home);
        Log.d("-", "onResume");
        IntentFilter intentFilter = new IntentFilter("com.agile.internetdemo.MainActivity");
        MainActivity.this.registerReceiver(mConnReceiver, intentFilter);

    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("-", "onPause");
        MainActivity.this.unregisterReceiver(mConnReceiver);
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private final BroadcastReceiver mConnReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {

            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo currentNetworkInfo = cm != null ? cm.getActiveNetworkInfo() : null;


            if (currentNetworkInfo != null && currentNetworkInfo.isConnectedOrConnecting()) {
                cached = false;
                minutesPassed = (int) System.currentTimeMillis();
                recreate();
                Toast.makeText(getApplicationContext(), "Connected", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection.\nMake sure your Wi-Fi or cellural data is turned on,then try again.",
                        Toast.LENGTH_LONG).show();
            }
        }
    };

}

