package com.ncl.team20.seatonvalley;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.jsoup.Jsoup;

public class WPPostDetails extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postdetails);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        WebView webView = findViewById(R.id.postwebview);
        Intent i = getIntent();
        @SuppressWarnings("ConstantConditions") int position = i.getExtras().getInt("itemPosition");


        if (NewsActivity.active
                ) {
            Log.e("WpPostDetails ", "  title is " + NewsActivity.mListPost.get(position).getTitle().getRendered());


            String title = Jsoup.parse(NewsActivity.mListPost.get(position).getTitle().getRendered()).text();
            setTitle(title);

            ConnectionDetector detector = new ConnectionDetector(WPPostDetails.this);

            if (detector.isInternetAvailable()) {
                webView.getSettings().setJavaScriptEnabled(true);
                webView.loadUrl(NewsActivity.mListPost.get(position).getLink());
                // Open WebView Inside the App.
                webView.setWebViewClient(new WebViewClient());
            } else {
                this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
            }
        }


        if (EventsActivity.active
                ) {
            Log.e("WpPostDetails ", "  title is " + EventsActivity.mListPost.get(position).getTitle().getRendered());


            String title = Jsoup.parse(EventsActivity.mListPost.get(position).getTitle().getRendered()).text();
            setTitle(title);

            ConnectionDetector detector = new ConnectionDetector(WPPostDetails.this);

            if (detector.isInternetAvailable()) {
                webView.getSettings().setJavaScriptEnabled(true);
                webView.loadUrl(EventsActivity.mListPost.get(position).getLink());
                // Open WebView Inside the App.
                webView.setWebViewClient(new WebViewClient());
            } else {
                this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
            }
        }

    }

    private final BroadcastReceiver mConnReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {

            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo currentNetworkInfo = cm != null ? cm.getActiveNetworkInfo() : null;

            if (currentNetworkInfo != null && currentNetworkInfo.isConnectedOrConnecting()) {
                recreate();
                Toast.makeText(getApplicationContext(), "Connected", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection.\nMake sure your Wi-Fi or cellural data is turned on,then try again.",
                        Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("-", "onResume");
        IntentFilter intentFilter = new IntentFilter("com.agile.internetdemo.MainActivity");
        WPPostDetails.this.registerReceiver(mConnReceiver, intentFilter);

    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("-", "onPause");
        WPPostDetails.this.unregisterReceiver(mConnReceiver);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
