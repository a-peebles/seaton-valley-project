package com.ncl.team20.seatonvalley;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("Home");

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        final ImageButton btnNews = findViewById(R.id.btnNews);
        final ImageButton btnTwitter = findViewById(R.id.btnTwitter);
        final ImageButton btnEvents = findViewById(R.id.btnEvents);
        final ImageButton btnFind = findViewById(R.id.btnFind);
        final ImageButton btnContact = findViewById(R.id.btnContact);
        final ImageButton btnReport = findViewById(R.id.btnReport);
        final ImageButton btnCouncil = findViewById(R.id.btnCouncil);
        final ImageButton btnInfo = findViewById(R.id.btnInfo);
        final ImageButton btnSettings = findViewById(R.id.btnSettings);
        final LinearLayout carousel = findViewById(R.id.carousel);
        final LinearLayout weatherLayout = findViewById(R.id.weather);
        final TextView temperatureView = weatherLayout.findViewById(R.id.weather_temperature);
        final ImageView weatherIcon = carousel.findViewById(R.id.weather_icon);
        //latitude and longitude of centre point in Seaton Valley
        double longitude = -1.518362;
        double latitude = 55.084432;
        //key to access openweathermap api
        String API_KEY = "97517c7d1e1d037af35cd1fb72095a09";
        String query = "lat="+ latitude +"&lon="+ longitude +"&appid="+ API_KEY +"&units=metric";
        //creates a request for JSON data at point of latitude and longitude
        String BASE_URL = "http://api.openweathermap.org/data/2.5/weather?";
        final String[] weatherIconCode = new String[1];
        final String IMAGES_URL = "http://openweathermap.org/img/w/";
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, BASE_URL + query,null, new Response.Listener<JSONObject>() {
            /**
             * runs if the JSON data is successfully retrieved
             * @author Alex Peebles
             * @param response data received from request
             *
             */
            @Override
            public void onResponse(JSONObject response) {

                try {
                    JSONObject mainObject = response.getJSONObject("main");
                    JSONArray weatherArray = response.getJSONArray("weather");
                    JSONObject weatherObject = (JSONObject) weatherArray.get(0);
                    //sets the temp textView text to the current celsius temperature
                    temperatureView.setText(String.format("%s\u2103", mainObject.getDouble("temp")));
                    //retrieves a weather icon code that corresponds to an image
                    weatherIconCode[0] = weatherObject.getString("icon");
                    //initialise Piccasso API
                    Picasso picasso = Picasso.with(getApplicationContext());
                    //retrieves image from the url using the weather icon code and places it in an ImageView
                    picasso.load(String.format("%s%s.png", IMAGES_URL, weatherIconCode[0])).resize(100,100).into(weatherIcon);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener(){
            /**
             * displays a toast if the JSON request encountered an error
             * @param error error information
             */
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(),  R.string.weather_error, Toast.LENGTH_LONG).show();

            }

        });
        Volley.newRequestQueue(getApplicationContext()).add(jsonObjectRequest);


        btnNews.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), NewsActivity.class);
                startActivity(intent);
            }
        });
        btnTwitter.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), TwitterActivity.class);
                startActivity(intent);
            }
        });
        btnEvents.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), EventsActivity.class);
                startActivity(intent);
            }
        });
        btnFind.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), FindActivity.class);
                startActivity(intent);
            }
        });
        btnContact.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), ContactActivity.class);
                startActivity(intent);
            }
        });
        btnReport.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), ReportActivity.class);
                startActivity(intent);
            }
        });
        btnCouncil.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), CouncilActivity.class);
                startActivity(intent);
            }
        });
        btnInfo.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), InfoActivity.class);
                startActivity(intent);
            }
        });
        btnSettings.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent(getApplicationContext(), SettingsActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(this, MainActivity.class);
             startActivity(intent);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
