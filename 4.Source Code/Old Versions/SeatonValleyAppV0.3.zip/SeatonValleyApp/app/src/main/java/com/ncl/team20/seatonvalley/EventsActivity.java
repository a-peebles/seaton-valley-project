package com.ncl.team20.seatonvalley;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.ncl.team20.seatonvalley.rest_api_reader.Model;
import com.ncl.team20.seatonvalley.rest_api_reader.RecyclerViewAdapter;
import com.ncl.team20.seatonvalley.rest_api_reader.RetrofitArrayApi;

import org.jsoup.Jsoup;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import okhttp3.Cache;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class EventsActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private ProgressBar progressBar;
    private ArrayList<Model> list;
    private RecyclerViewAdapter adapter;
    public static List<WPPost> mListPost;
    public static boolean active = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        active = true;
        NewsActivity.active=false;
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Events");

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        RecyclerView recyclerView = findViewById(R.id.recycler_view_events);
        progressBar = findViewById(R.id.progressbar);
        progressBar.setVisibility(View.GONE);


        LinearLayoutManager mLayoutManager = new LinearLayoutManager(EventsActivity.this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);

        list = new ArrayList<>();

        ConnectionDetector detector = new ConnectionDetector(EventsActivity.this);

        if (detector.isInternetAvailable()) {
            progressBar.setVisibility(View.VISIBLE);
            getRetrofit();
            adapter = new RecyclerViewAdapter(list, EventsActivity.this);
            recyclerView.setAdapter(adapter);
        } else {
            getRetrofit();
            adapter = new RecyclerViewAdapter(list, EventsActivity.this);
            recyclerView.setAdapter(adapter);
            this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
     }

    private void getRetrofit() {

        String baseURL = "http://seatonvalleycommunitycouncil.gov.uk/";
        String request = "/wp-json/wp/v2/posts?per_page=100&categories=";
        String category = "16";

        int cacheSize = 10 * 1024 * 1024;
        Cache cache = new Cache(getCacheDir(), cacheSize);

        OkHttpClient okHttpClient = new OkHttpClient.Builder()
                .cache(cache)
                .addInterceptor(new Interceptor() {
                    @Override
                    public okhttp3.Response intercept(Interceptor.Chain chain)
                            throws IOException {
                        Request request = chain.request();
                        ConnectionDetector detector = new ConnectionDetector(EventsActivity.this);

                        if (!detector.isInternetAvailable()) {
                            int maxStale = 60 * 60 * 24 * 28; // tolerate 4-weeks stale \
                            request = request
                                    .newBuilder()
                                    .header("Cache-Control", "public, only-if-cached, max-stale=" + maxStale)
                                    .build();
                        }
                        return chain.proceed(request);
                    }
                })
                .build();

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl(baseURL)
                .client(okHttpClient)
                .addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        RetrofitArrayApi service = retrofit.create(RetrofitArrayApi.class);
        Call<List<WPPost>> call = service.getPostInfo(baseURL + request + category);


        call.enqueue(new Callback<List<WPPost>>() {
            @Override
            public void onResponse(Call<List<WPPost>> call, Response<List<WPPost>> response) {
                Log.e("mainactivity", " response " + response.body());
                mListPost = response.body();
                progressBar.setVisibility(View.GONE);
                for (int i = 0; i < response.body().size(); i++) {

                    Log.e("main ", " title " + response.body().get(i).getTitle().getRendered() + "" +
                            response.body().get(i).getId());

                    String title = response.body().get(i).getTitle().getRendered();
                    title = Jsoup.parse(title).text();

                    String description = response.body().get(i).getExcerpt().getRendered();
                    description = description.replace("<p>", "");
                    description = description.replace("</p>", "");
                    description = description.replace("[&hellip;]", "");
                    description = description.replace("&nbsp;", "");
                    description = Jsoup.parse(description).text();


                    if (description.length() > 100) {
                        description = description.substring(0, 100) + "...";
                    }

                    list.add(new Model(title,
                            description
                    ));
                }
                adapter.notifyDataSetChanged();

            }

            @Override
            public void onFailure(Call<List<WPPost>> call, Throwable t) {

            }
        });

    }

    private final BroadcastReceiver mConnReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {


            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo currentNetworkInfo = cm != null ? cm.getActiveNetworkInfo() : null;


            if (currentNetworkInfo != null && currentNetworkInfo.isConnectedOrConnecting()) {
                recreate();
                Toast.makeText(getApplicationContext(), "Connected", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection.\nMake sure your Wi-Fi or cellural data is turned on,then try again.",
                        Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("-", "onResume");
        IntentFilter intentFilter = new IntentFilter("com.agile.internetdemo.MainActivity");
        EventsActivity.this.registerReceiver(mConnReceiver, intentFilter);

    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("-", "onPause");
        EventsActivity.this.unregisterReceiver(mConnReceiver);
    }


    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
