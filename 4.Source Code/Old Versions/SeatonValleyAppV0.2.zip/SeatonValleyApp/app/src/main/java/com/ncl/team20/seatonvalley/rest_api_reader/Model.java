package com.ncl.team20.seatonvalley.rest_api_reader;


public class Model {

    public final String title;
    public final String description;

    public Model(String mtitle, String mdescription) {

        this.title = mtitle;
        this.description = mdescription;
    }
}

