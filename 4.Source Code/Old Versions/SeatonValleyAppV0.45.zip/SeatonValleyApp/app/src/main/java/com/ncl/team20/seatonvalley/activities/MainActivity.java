
package com.ncl.team20.seatonvalley.activities;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.ncl.team20.seatonvalley.ConnectionDetector;
import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.data.ClientRequestBuilder;
import com.ncl.team20.seatonvalley.data.posts.Beautifier;
import com.ncl.team20.seatonvalley.data.posts.Model;
import com.ncl.team20.seatonvalley.adapters.PostsRecyclerViewAdapter;
import com.ncl.team20.seatonvalley.data.posts.Post;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class MainActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private ProgressBar progressBar;
    private ArrayList<Model> list;
    private PostsRecyclerViewAdapter adapter;
    public static List<Post> mListPost;

    public static boolean active = false;

    private final static int POSTS = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("Home");

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        final ImageButton btnNews = findViewById(R.id.btnNews);
        final ImageButton btnTwitter = findViewById(R.id.btnTwitter);
        final ImageButton btnEvents = findViewById(R.id.btnEvents);
        final ImageButton btnFind = findViewById(R.id.btnFind);
        final ImageButton btnContact = findViewById(R.id.btnContact);
        final ImageButton btnReport = findViewById(R.id.btnReport);
        final ImageButton btnCouncil = findViewById(R.id.btnCouncil);
        final ImageButton btnInfo = findViewById(R.id.btnInfo);
        final ImageButton btnSettings = findViewById(R.id.btnSettings);

        final LinearLayout carousel = findViewById(R.id.carousel);
        final LinearLayout weatherLayout = findViewById(R.id.weather);
        final TextView temperatureView = weatherLayout.findViewById(R.id.weather_temperature);
        final ImageView weatherIcon = carousel.findViewById(R.id.weather_icon);
        //latitude and longitude of centre point in Seaton Valley
        double longitude = -1.518362;
        double latitude = 55.084432;
        //key to access openweathermap api
        String API_KEY = "97517c7d1e1d037af35cd1fb72095a09";
        String query = "lat=" + latitude + "&lon=" + longitude + "&appid=" + API_KEY + "&units=metric";
        //creates a request for JSON data at point of latitude and longitude
        String BASE_URL = "http://api.openweathermap.org/data/2.5/weather?";
        final String[] weatherIconCode = new String[1];
        final String IMAGES_URL = "http://openweathermap.org/img/w/";

        RecyclerView recyclerView = findViewById(R.id.recycler_view_latest);
        progressBar = findViewById(R.id.progressbar);
        progressBar.setVisibility(View.GONE);

        LinearLayoutManager mLayoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(mLayoutManager);

        list = new ArrayList<>();
        ConnectionDetector detector = new ConnectionDetector(MainActivity.this);

        if (detector.isInternetAvailable()) {

            progressBar.setVisibility(View.VISIBLE);
            getLatestNews();
            adapter = new PostsRecyclerViewAdapter(list, MainActivity.this);
            recyclerView.setAdapter(adapter);

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, BASE_URL + query, null, new Response.Listener<JSONObject>() {
                /**
                 * runs if the JSON data is successfully retrieved
                 * @author Alex Peebles
                 * @param response data received from request
                 *
                 */
                @Override
                public void onResponse(JSONObject response) {


                    try {
                        JSONObject mainObject = response.getJSONObject("main");
                        JSONArray weatherArray = response.getJSONArray("weather");
                        JSONObject weatherObject = (JSONObject) weatherArray.get(0);
                        //sets the temp textView text to the current celsius temperature
                        temperatureView.setText(String.format("%s\u2103", mainObject.getDouble("temp")));
                        //retrieves a weather icon code that corresponds to an image
                        weatherIconCode[0] = weatherObject.getString("icon");
                        //initialise Piccasso API
                        Picasso picasso = Picasso.with(getApplicationContext());
                        //retrieves image from the url using the weather icon code and places it in an ImageView
                        picasso.load(String.format("%s%s.png", IMAGES_URL, weatherIconCode[0])).resize(100, 100).into(weatherIcon);


                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }, new Response.ErrorListener() {
                /**
                 * displays a toast if the JSON request encountered an error
                 * @param error error information
                 */
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(getApplicationContext(), R.string.weather_error, Toast.LENGTH_LONG).show();
                }

            });
            Volley.newRequestQueue(getApplicationContext()).add(jsonObjectRequest);
        } else {
            getLatestNews();
            adapter = new PostsRecyclerViewAdapter(list, MainActivity.this);
            recyclerView.setAdapter(adapter);
            this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }

        btnNews.setOnClickListener(v -> {
            btnNews.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), NewsActivity.class);
            startActivity(intent);
        });
        btnTwitter.setOnClickListener(v -> {
            btnTwitter.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), TwitterActivity.class);
            startActivity(intent);
        });
        btnEvents.setOnClickListener(v -> {
            btnEvents.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), EventsActivity.class);
            startActivity(intent);
        });
        btnFind.setOnClickListener(v -> {
            btnFind.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), FindActivity.class);
            startActivity(intent);
        });
        btnContact.setOnClickListener(v -> {
            btnContact.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), ContactActivity.class);
            startActivity(intent);
        });
        btnReport.setOnClickListener(v -> {
            btnReport.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), ReportActivity.class);
            startActivity(intent);
        });
        btnCouncil.setOnClickListener(v -> {
            btnCouncil.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), CouncilActivity.class);
            startActivity(intent);
        });
        btnInfo.setOnClickListener(v -> {
            btnInfo.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), InfoActivity.class);
            startActivity(intent);
        });
        btnSettings.setOnClickListener(v -> {
            btnSettings.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), SettingsActivity.class);
            startActivity(intent);
        });
    }


    private void getLatestNews() {

        EventsActivity.active = false;
        NewsActivity.active = false;
        MainActivity.active = true;

        String baseURL = "http://seatonvalleycommunitycouncil.gov.uk/";
        String request = "/wp-json/wp/v2/posts?per_page=";
        request += String.valueOf(POSTS) + "&categories=";
        String category = "16";

        ClientRequestBuilder clientRequestBuilder = new ClientRequestBuilder();

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl(baseURL)
                .client(ClientRequestBuilder.getCacheClient(this))
                .addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        Model.RetrofitArrayApi service = retrofit.create(Model.RetrofitArrayApi.class);
        Call<List<Post>> call = service.getPostInfo(baseURL + request + category);

        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(@SuppressWarnings("NullableProblems") Call<List<Post>> call, @SuppressWarnings("NullableProblems") retrofit2.Response<List<Post>> response) {

                mListPost = response.body();

                progressBar.setVisibility(View.GONE);

                //noinspection ConstantConditions
                for (int i = 0; i < response.body().size(); i++) {

                    @SuppressWarnings("ConstantConditions") String title = response.body().get(i).getTitle().getRendered();
                    @SuppressWarnings("ConstantConditions") String description = response.body().get(i).getExcerpt().getRendered();
                    Beautifier beautify = new Beautifier(title, description);

                    title = beautify.getTitle();
                    description = beautify.getDescription();

                    list.add(new Model(title,
                            description));
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(@SuppressWarnings("NullableProblems") Call<List<Post>> call, @SuppressWarnings("NullableProblems") Throwable t) {

            }
        });

    }


    @Override
    protected void onResume() {
        super.onResume();
        EventsActivity.active = false;
        NewsActivity.active = false;
        MainActivity.active = true;


        final ImageButton btnNews = findViewById(R.id.btnNews);
        final ImageButton btnTwitter = findViewById(R.id.btnTwitter);
        final ImageButton btnEvents = findViewById(R.id.btnEvents);
        final ImageButton btnFind = findViewById(R.id.btnFind);
        final ImageButton btnContact = findViewById(R.id.btnContact);
        final ImageButton btnReport = findViewById(R.id.btnReport);
        final ImageButton btnCouncil = findViewById(R.id.btnCouncil);
        final ImageButton btnInfo = findViewById(R.id.btnInfo);
        final ImageButton btnSettings = findViewById(R.id.btnSettings);

        btnNews.setEnabled(true);
        btnTwitter.setEnabled(true);
        btnEvents.setEnabled(true);
        btnFind.setEnabled(true);
        btnContact.setEnabled(true);
        btnReport.setEnabled(true);
        btnCouncil.setEnabled(true);
        btnInfo.setEnabled(true);
        btnSettings.setEnabled(true);


        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setCheckedItem(R.id.nav_home);
        Log.d("-", "onResume");
        IntentFilter intentFilter = new IntentFilter("com.ncl.team20.seatonvalley.activities.MainActivity");
        MainActivity.this.registerReceiver(mConnReceiver, intentFilter);

    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("-", "onPause");
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }


    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    private final BroadcastReceiver mConnReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {

            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo currentNetworkInfo = cm != null ? cm.getActiveNetworkInfo() : null;

            if (currentNetworkInfo != null && currentNetworkInfo.isConnectedOrConnecting()) {
                recreate();
                Toast.makeText(getApplicationContext(), "Connected", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection.\nMake sure your Wi-Fi or cellural data is turned on,then try again.",
                        Toast.LENGTH_LONG).show();
            }
        }
    };


}

