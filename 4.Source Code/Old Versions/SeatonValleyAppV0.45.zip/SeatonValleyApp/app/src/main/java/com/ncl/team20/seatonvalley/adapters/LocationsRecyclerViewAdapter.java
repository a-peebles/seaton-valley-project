package com.ncl.team20.seatonvalley.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ncl.team20.seatonvalley.activities.MainActivity;
import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.DisplayPostDetails;
import com.ncl.team20.seatonvalley.data.posts.Model;

import java.util.ArrayList;


class LocationsRecyclerViewAdapter extends RecyclerView.Adapter {

    private final ArrayList<Model> dataset;
    private final Context mContext;
    public LocationsRecyclerViewAdapter(ArrayList<Model> mlist, Context context) {
        this.dataset = mlist;
        this.mContext = context;
    }

    public static class ImageTypeViewHolder extends RecyclerView.ViewHolder{

        final TextView title;
        final TextView description;

        final CardView card;
        public ImageTypeViewHolder(View itemView) {
            super(itemView);

            this.title = itemView.findViewById(R.id.title);
            this.description = itemView.findViewById(R.id.description);
            this.card = itemView.findViewById(R.id.card);
        }
    }
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View viewOne = LayoutInflater.from( parent.getContext()).inflate(R.layout.postdetails, parent, false);
        if(MainActivity.active) {
            View viewTwo = LayoutInflater.from( parent.getContext()).inflate(R.layout.latestpostdetails, parent, false);
            return new ImageTypeViewHolder(viewTwo) ;
        }
        return new ImageTypeViewHolder(viewOne) ;
    }

    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final Model object = dataset.get(position);

        ( (ImageTypeViewHolder) holder).title.setText( object.title );
        ( (ImageTypeViewHolder) holder).description.setText( object.description );


        ( (ImageTypeViewHolder) holder).card.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, DisplayPostDetails.class);
            intent.putExtra("itemPosition", position);
            mContext.startActivity(intent);
        });

        ( (ImageTypeViewHolder) holder).title.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, DisplayPostDetails.class);
            intent.putExtra("itemPosition", position);
            mContext.startActivity(intent);
        });

        ( (ImageTypeViewHolder) holder).description.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, DisplayPostDetails.class);
            intent.putExtra("itemPosition", position);
            mContext.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return dataset.size() ;
    }
}
