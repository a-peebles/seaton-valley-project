package com.ncl.team20.seatonvalley.activities;

/**
 * Created by Stelios Ioannou on 26/02/2018.
 */

public class PlaceActivity {
}
