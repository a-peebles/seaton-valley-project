package com.ncl.team20.seatonvalley.project_interfaces;

import com.ncl.team20.seatonvalley.data.posts.Post;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

public interface RetrofitArrayInterface {

    @GET
    Call<List<Post>> getPostInfo(@Url String url);

}
