package com.ncl.team20.seatonvalley.data.posts;


import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Url;

public class Model {

    public final String title;
    public final String description;

    public Model(String mtitle, String mdescription) {

        this.title = mtitle;
        this.description = mdescription;
    }

    public interface RetrofitArrayApi {

        @GET
        Call<List<Post>> getPostInfo(@Url String url);

    }
}

