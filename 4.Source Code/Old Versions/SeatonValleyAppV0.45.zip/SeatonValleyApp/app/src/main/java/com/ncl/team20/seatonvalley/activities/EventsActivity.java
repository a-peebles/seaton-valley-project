package com.ncl.team20.seatonvalley.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.ncl.team20.seatonvalley.ConnectionDetector;
import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.data.ClientRequestBuilder;
import com.ncl.team20.seatonvalley.data.posts.Beautifier;
import com.ncl.team20.seatonvalley.data.posts.Model;
import com.ncl.team20.seatonvalley.adapters.PostsRecyclerViewAdapter;
import com.ncl.team20.seatonvalley.data.posts.Post;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class EventsActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private ProgressBar progressBar;
    private ArrayList<Model> list;
    private PostsRecyclerViewAdapter adapter;
    public static List<Post> mListPost;

    public static boolean active = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Events");

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        RecyclerView recyclerView = findViewById(R.id.recycler_view_events);
        progressBar = findViewById(R.id.progressbar);
        progressBar.setVisibility(View.GONE);


        LinearLayoutManager mLayoutManager = new LinearLayoutManager(EventsActivity.this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(mLayoutManager);

        list = new ArrayList<>();

        ConnectionDetector detector = new ConnectionDetector(EventsActivity.this);

        if (detector.isInternetAvailable()) {
            progressBar.setVisibility(View.VISIBLE);
            getEvents();
            adapter = new PostsRecyclerViewAdapter(list, EventsActivity.this);
            recyclerView.setAdapter(adapter);
        } else {
            getEvents();
            adapter = new PostsRecyclerViewAdapter(list, EventsActivity.this);
            recyclerView.setAdapter(adapter);
            this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
    }

    private void getEvents() {

        EventsActivity.active = true;
        NewsActivity.active = false;
        MainActivity.active = false;

        String baseURL = "http://seatonvalleycommunitycouncil.gov.uk/";
        String request = "/wp-json/wp/v2/posts?per_page=";
        int POSTS = 100;
        request += String.valueOf(POSTS) + "&categories=";
        String category = "17";

        ClientRequestBuilder clientRequestBuilder = new ClientRequestBuilder();

        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl(baseURL)
                .client(ClientRequestBuilder.getCacheClient(this))
                .addConverterFactory(GsonConverterFactory.create());

        Retrofit retrofit = builder.build();

        Model.RetrofitArrayApi service = retrofit.create(Model.RetrofitArrayApi.class);
        Call<List<Post>> call = service.getPostInfo(baseURL + request + category);

        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(@SuppressWarnings("NullableProblems") Call<List<Post>> call, @SuppressWarnings("NullableProblems") retrofit2.Response<List<Post>> response) {

                mListPost = response.body();

                progressBar.setVisibility(View.GONE);

                //noinspection ConstantConditions
                for (int i = 0; i < response.body().size(); i++) {

                    @SuppressWarnings("ConstantConditions") String title = response.body().get(i).getTitle().getRendered();
                    @SuppressWarnings("ConstantConditions") String description = response.body().get(i).getExcerpt().getRendered();
                    Beautifier beautify = new Beautifier(title, description);

                    title = beautify.getTitle();
                    description = beautify.getDescription();

                    list.add(new Model(title,
                            description));
                }

                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(@SuppressWarnings("NullableProblems") Call<List<Post>> call, @SuppressWarnings("NullableProblems") Throwable t) {

            }
        });

    }

    private final BroadcastReceiver mConnReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {

            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo currentNetworkInfo = cm != null ? cm.getActiveNetworkInfo() : null;

            if (currentNetworkInfo != null && currentNetworkInfo.isConnectedOrConnecting()) {
                recreate();
                Toast.makeText(getApplicationContext(), "Connected", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection.\nMake sure your Wi-Fi or cellural data is turned on,then try again.",
                        Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        Log.d("-", "onResume");
        IntentFilter intentFilter = new IntentFilter("com.agile.internetdemo.MainActivity");
        EventsActivity.this.registerReceiver(mConnReceiver, intentFilter);

    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("-", "onPause");
        EventsActivity.this.unregisterReceiver(mConnReceiver);
    }


    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
