package com.ncl.team20.seatonvalley;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class DisplayPlaceDetailsTest {
    @Test
    public void onCreate() throws Exception {
    }

    @Test
    public void onResume() throws Exception {
    }

    @Test
    public void onBackPressed() throws Exception {
    }

    @Test
    public void onSupportNavigateUp() throws Exception {
    }

}