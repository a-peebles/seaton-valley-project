package com.ncl.team20.seatonvalley.components;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class DrawerTest {
    @Test
    public void onNavigationItemSelected() throws Exception {
    }

    @Test
    public void onBackPressed() throws Exception {
    }

    @Test
    public void onSupportNavigateUp() throws Exception {
    }

}