package com.ncl.team20.seatonvalley.data.places;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class OpeningHoursTest {
    @Test
    public void getOpenNow() throws Exception {
    }

    @Test
    public void setOpenNow() throws Exception {
    }

    @Test
    public void getWeekdayText() throws Exception {
    }

    @Test
    public void setWeekdayText() throws Exception {
    }

}