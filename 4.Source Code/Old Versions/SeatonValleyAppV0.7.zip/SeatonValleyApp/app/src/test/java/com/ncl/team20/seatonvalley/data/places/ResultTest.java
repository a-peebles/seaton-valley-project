package com.ncl.team20.seatonvalley.data.places;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class ResultTest {
    @Test
    public void getGeometry() throws Exception {
    }

    @Test
    public void setGeometry() throws Exception {
    }

    @Test
    public void getIcon() throws Exception {
    }

    @Test
    public void setIcon() throws Exception {
    }

    @Test
    public void getId() throws Exception {
    }

    @Test
    public void setId() throws Exception {
    }

    @Test
    public void getName() throws Exception {
    }

    @Test
    public void setName() throws Exception {
    }

    @Test
    public void getOpeningHours() throws Exception {
    }

    @Test
    public void setOpeningHours() throws Exception {
    }

    @Test
    public void getPlaceId() throws Exception {
    }

    @Test
    public void setPlaceId() throws Exception {
    }

    @Test
    public void getRating() throws Exception {
    }

    @Test
    public void setRating() throws Exception {
    }

    @Test
    public void getReference() throws Exception {
    }

    @Test
    public void setReference() throws Exception {
    }

    @Test
    public void getScope() throws Exception {
    }

    @Test
    public void setScope() throws Exception {
    }

    @Test
    public void getTypes() throws Exception {
    }

    @Test
    public void setTypes() throws Exception {
    }

    @Test
    public void getVicinity() throws Exception {
    }

    @Test
    public void setVicinity() throws Exception {
    }

}