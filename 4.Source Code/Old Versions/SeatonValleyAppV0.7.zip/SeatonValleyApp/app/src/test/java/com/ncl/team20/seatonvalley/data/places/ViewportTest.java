package com.ncl.team20.seatonvalley.data.places;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class ViewportTest {
    @Test
    public void getNortheast() throws Exception {
    }

    @Test
    public void setNortheast() throws Exception {
    }

    @Test
    public void getSouthwest() throws Exception {
    }

    @Test
    public void setSouthwest() throws Exception {
    }

}