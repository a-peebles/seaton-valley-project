package com.ncl.team20.seatonvalley.data.places;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by Alex on 12/03/2018.
 */
public class GeometryTest {
    @Test
    public void getLocation() throws Exception {
    }

    @Test
    public void setLocation() throws Exception {
    }

    @Test
    public void getViewport() throws Exception {
    }

    @Test
    public void setViewport() throws Exception {
    }

}