package com.ncl.team20.seatonvalley.activities;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import org.apache.commons.io.FileUtils;

import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.components.basic.Drawer;

/**
 * @author Stelios Ioannou
 * @since 20/02/2018
 * Last Edit: 02/03/2018 by Stelios Ioannou
 * <p>
 * This class is used to control the applications settings extends the Drawer,to display the drawer.
 */
public class SettingsActivity extends Drawer {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        //Custom Animation on Create
        overridePendingTransition(R.anim.anim_slide_in_left, R.anim.anim_slide_out_left);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(R.string.settingsTitle);

        NavigationView navigationView = findViewById(R.id.nav_view);

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_settings);

        final Button btnClearCache = findViewById(R.id.btnClearCache);

        btnClearCache.setOnClickListener(v ->

        {
            btnClearCache.setEnabled(false);
            clearCache();
        });

        //Creates a SharedPreferences object
        SharedPreferences checked = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this);

        //Create a Switch object for the relevant Switch in content settings.
        final Switch switchNotifications = findViewById(R.id.toggleNotifications);

        //Sets the Switch to the relevant state that is saved in SharedPreferences.
        switchNotifications.setChecked(checked.getBoolean("key", true));

        //On Switch
        switchNotifications.setOnCheckedChangeListener((buttonView, isChecked) -> {
            //Saves the relevant info to the SharedPreferences
            if (isChecked)
                PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit().putBoolean("key", true).apply();
            else {
                PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit().putBoolean("key", false).apply();
            }
            //
            boolean isEnabled = PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this)
                    .getBoolean("key", true);
            //Enables or Disables Notification
            MainActivity.notificationEnabler(isEnabled);
        });

        //Spinner to select number of posts to display.
        final Spinner newsToDisplay = findViewById(R.id.news_to_display);

        //Def Value 0,0 is the position of the element in the list,since list[0] is 10 , the default value is 10
        newsToDisplay.setSelection(checked.getInt("position-news", 0));

        //Updates News to Display on Selected Items
        newsToDisplay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(@NonNull AdapterView<?> adapterView, View view, int i, long l) {
                int posts = Integer.parseInt(String.valueOf(adapterView.getItemAtPosition(i)));
                PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit().putInt("news-posts", posts).apply();
                PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit().putInt("position-news", i).apply();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

        final Spinner eventsToDisplay = findViewById(R.id.events_to_display);

        //Def Value 0,0 is the position of the element in the list,since list[0] is 10 , the default value is 10
        eventsToDisplay.setSelection(checked.getInt("position-events", 0));

        //Updates Events to Display on Selected Items
        eventsToDisplay.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(@NonNull AdapterView<?> adapterView, View view, int i, long l) {
                int posts = Integer.parseInt(String.valueOf(adapterView.getItemAtPosition(i)));
                PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit().putInt("events-posts", posts).apply();
                PreferenceManager.getDefaultSharedPreferences(SettingsActivity.this).edit().putInt("position-events", i).apply();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });

    }

    //Clears App Cache
    private void clearCache() {
        FileUtils.deleteQuietly(this.getCacheDir());

        Context context = getApplicationContext();
        CharSequence text = "Your cache has been cleared.";
        int duration = Toast.LENGTH_LONG;
        //Display the Message.
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }


    //Ensures that on resume,that the correct element is selected.
    @Override
    public void onResume() {
        super.onResume();
        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_settings);
    }


}
