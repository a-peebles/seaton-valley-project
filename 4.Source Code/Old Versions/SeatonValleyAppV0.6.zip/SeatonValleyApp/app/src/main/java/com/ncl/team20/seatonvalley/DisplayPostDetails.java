package com.ncl.team20.seatonvalley;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v7.widget.Toolbar;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.ncl.team20.seatonvalley.activities.EventsActivity;
import com.ncl.team20.seatonvalley.activities.MainActivity;
import com.ncl.team20.seatonvalley.activities.NewsActivity;
import com.ncl.team20.seatonvalley.components.Connection;

import org.jsoup.Jsoup;

/**
 * @author Stelios Ioannou
 * @since 20/02/2018
 * Last Edit: 02/03/2018 by Stelios Ioannou
 * <p>
 * This class extends the Connection abstract class.
 * It's used to open the links of the posts  news,latest news and events.
 */
public class DisplayPostDetails extends Connection {

    //Creates a ConnectionDetector to determine connectivity.
    private final ConnectionDetector detector = new ConnectionDetector(DisplayPostDetails.this);

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        //Sets UI elements
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postdetails);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        //Opens inside an internal Webview.
        viewPost();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void viewPost() {

        WebView webView = findViewById(R.id.postwebview);
        Intent i = getIntent();

        //Gets the position of the post.
        @SuppressWarnings("ConstantConditions") int position = i.getExtras().getInt("itemPosition");
        //Gets what type of post it is.
        int type = i.getExtras().getInt("type");

        //For Each if statement below it checks if there is internet connection and if so it opens the link,otherwise
        //it won't open and display an error message and register a Receiver.
        //The jsoup statement converts the title to a proper encoding and then the title is set as a title for the activity

        //For the latest news post in the MainActivity section.
        if (type == 1) {
            String title = Jsoup.parse(MainActivity.mListPost.get(position).getTitle().getRendered()).text();
            setTitle(title);

            if (detector.isInternetAvailable()) {
                webView.getSettings().setJavaScriptEnabled(true);
                webView.loadUrl(MainActivity.mListPost.get(position).getLink());
                // Open WebView Inside the App.
                webView.setWebViewClient(new WebViewClient());
            } else {
                this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
            }
            //For the NewsActivity section.
        } else if (type == 2) {
            String title = Jsoup.parse(NewsActivity.mListPost.get(position).getTitle().getRendered()).text();
            setTitle(title);

            if (detector.isInternetAvailable()) {
                webView.getSettings().setJavaScriptEnabled(true);
                webView.loadUrl(NewsActivity.mListPost.get(position).getLink());
                // Open WebView Inside the App.
                webView.setWebViewClient(new WebViewClient());
            } else {
                this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
            }
            //For the Event section.
        } else if (type == 3) {
            String title = Jsoup.parse(EventsActivity.mListPost.get(position).getTitle().getRendered()).text();
            setTitle(title);

            if (detector.isInternetAvailable()) {
                webView.getSettings().setJavaScriptEnabled(true);
                webView.loadUrl(EventsActivity.mListPost.get(position).getLink());
                // Open WebView Inside the App.
                webView.setWebViewClient(new WebViewClient());
            } else {
                this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
            }
        }
    }

    //Enables the back-button.
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}
