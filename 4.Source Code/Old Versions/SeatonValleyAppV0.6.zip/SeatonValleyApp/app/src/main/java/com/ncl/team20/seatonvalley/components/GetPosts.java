package com.ncl.team20.seatonvalley.components;

import android.content.Context;
import android.view.View;
import android.widget.ProgressBar;

import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.adapters.PostsRecyclerViewAdapter;
import com.ncl.team20.seatonvalley.data.ClientRequestBuilder;
import com.ncl.team20.seatonvalley.data.posts.Beautifier;
import com.ncl.team20.seatonvalley.data.posts.ModelPost;
import com.ncl.team20.seatonvalley.data.posts.Post;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * @author Stelios Ioannou
 * @since 20/02/2018
 * Last Edit: 02/03/2018 by Stelios Ioannou
 * <p>
 * This abstract class is used as an Extension to MainActivity,NewsActivity,EventsActivity,to get the relevant posts.
 * This class is extended by the abstract class Connection.
 */
public abstract class GetPosts extends Connection {

    protected final ArrayList<ModelPost> list = new ArrayList<>();
    protected PostsRecyclerViewAdapter adapter;
    private Beautifier beautify;
    protected ProgressBar progressBar;
    public static List<Post> mListPost;


    void getPosts(int POSTS, String category, Context context) {

        String baseURL = getString(R.string.baseURL); //Standar URL that's make the request
        String request = getString(R.string.request); //Standar Request.
        request += POSTS + getString(R.string.categories);

        //Makes a Retrofit builder with the Client of ClientRequestBuilder class.
        Retrofit.Builder builder = new Retrofit.Builder()
                .baseUrl(baseURL)
                .client(ClientRequestBuilder.getCacheClient(context))
                .addConverterFactory(GsonConverterFactory.create());

        //Creates the Retrofit object.
        Retrofit retrofit = builder.build();

        //Create the service.
        ModelPost.RetrofitArrayApi service = retrofit.create(ModelPost.RetrofitArrayApi.class);

        //Makes a List of Posts
        Call<List<Post>> call = service.getPostInfo(baseURL + request + category);

        //Populate each post
        call.enqueue(new Callback<List<Post>>() {
            @Override
            public void onResponse(@SuppressWarnings("NullableProblems") Call<List<Post>> call, @SuppressWarnings("NullableProblems") retrofit2.Response<List<Post>> response) {

                mListPost = response.body(); //Gets the requests response.

                progressBar.setVisibility(View.GONE); //Sets the progressBar to invisible.

                //for all posts
                //noinspection ConstantConditions
                for (int i = 0; i < response.body().size(); i++) {

                    //Gets Title
                    @SuppressWarnings("ConstantConditions") String title = response.body().get(i).getTitle().getRendered();
                    //Gets Description
                    @SuppressWarnings("ConstantConditions") String description = response.body().get(i).getExcerpt().getRendered();
                    beautify = new Beautifier(title, description);
                    //Beautifies them and stores them.
                    title = beautify.getTitle();
                    description = beautify.getDescription();

                    //Adds to a new ModelPost object.
                    list.add(new ModelPost(title,
                            description));
                }
                //Notify adapater for the change in data.
                adapter.notifyDataSetChanged();
            }

            @Override
            public void onFailure(@SuppressWarnings("NullableProblems") Call<List<Post>> call, @SuppressWarnings("NullableProblems") Throwable t) {

            }
        });
    }

}

