package com.ncl.team20.seatonvalley.services;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v4.app.NotificationCompat;

import com.google.firebase.messaging.RemoteMessage;
import com.ncl.team20.seatonvalley.activities.MainActivity;
import com.ncl.team20.seatonvalley.R;


/**
 * Service that gets a notification from the Firebase API.
 *
 * @author Stelios Ioannou
 * @since 23/02/2018
 * Last Edit: 02/03/2018 by Stelios Ioannou
 */
public class SeatonFirebaseMessagingService extends com.google.firebase.messaging.FirebaseMessagingService {

    /**
     * When a mesaged is received,displays the notification.
     *
     * @param remoteMessage the message that was sent from the Firebase Messaging Service
     */
    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0 /* request code */, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        //Notification Attributes
        //noinspection ConstantConditions
        @SuppressWarnings({"deprecation", "ConstantConditions"}) NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(remoteMessage.getNotification().getTitle())
                .setContentText(remoteMessage.getNotification().getBody())
                .setAutoCancel(true)
                .setLights(Color.BLUE, 500, 500)
                .setStyle(new NotificationCompat.InboxStyle())
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        //noinspection ConstantConditions
        notificationManager.notify(0 /* ID of notification */, notificationBuilder.build());
    }
}