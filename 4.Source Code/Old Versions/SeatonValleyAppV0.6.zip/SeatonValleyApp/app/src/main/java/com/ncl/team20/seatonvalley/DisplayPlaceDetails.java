package com.ncl.team20.seatonvalley;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;

import com.ncl.team20.seatonvalley.activities.PlacesActivity;
import com.ncl.team20.seatonvalley.components.Connection;

/**
 * @author Stelios Ioannou
 * @since 20/02/2018
 * Last Edit: 02/03/2018 by Stelios Ioannou
 * <p>
 * This class extends the Connection abstract class.
 * It's used to open the links of the places in Google Maps or in a browser.
 */
public class DisplayPlaceDetails extends Connection {

    //Creates a ConnectionDetector to determine connectivity.
    private final ConnectionDetector detector = new ConnectionDetector(DisplayPlaceDetails.this);

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        @SuppressWarnings("ConstantConditions") int position = i.getExtras().getInt("itemPosition");

        //Gets the current place position
        getPlace(position);
    }

    /**
     * Checks if there is internet connection and if so it opens the link of the place,otherwise
     * //it won't open and display an error message and register a Receiver.
     *
     * @param position the position in the list of the current place.
     */
    private void getPlace(int position) {
        String url = "https://www.google.com/maps/search/?api=1&query=";

        if (detector.isInternetAvailable()) {
            //Get Latitude
            url += PlacesActivity.mListPlace.getResults().get(position).getGeometry().getLocation().getLat();
            url += ",";
            //Get Longitude
            url += PlacesActivity.mListPlace.getResults().get(position).getGeometry().getLocation().getLng();
            url += "&query_place_id=";
            //Get Place Id
            url += PlacesActivity.mListPlace.getResults().get(position).getPlaceId();
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse(url));
            //Opens the Links
            startActivity(browserIntent);
        } else {
            this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
    }

    //On resume it registers the Receiver and then takes them back to the List of Places.
    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter intentFilter = new IntentFilter("");
        this.registerReceiver(mConnReceiver, intentFilter);
        onSupportNavigateUp();
        finish();
    }

    //Enable back button.
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}