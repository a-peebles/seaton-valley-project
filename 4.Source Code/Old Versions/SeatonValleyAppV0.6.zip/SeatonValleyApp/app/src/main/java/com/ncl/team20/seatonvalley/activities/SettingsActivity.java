package com.ncl.team20.seatonvalley.activities;

import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v7.widget.Toolbar;
import android.widget.Button;
import android.widget.Toast;

import org.apache.commons.io.FileUtils;

import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.components.Drawer;

/**
 * @author Stelios Ioannou
 * @since 20/02/2018
 * Last Edit: 02/03/2018 by Stelios Ioannou
 * <p>
 * This class is used to control the applications settings extends the Drawer,to display the drawer.
 */
public class SettingsActivity extends Drawer {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle(R.string.settingsTitle);

        NavigationView navigationView = findViewById(R.id.nav_view);

        navigationView.setNavigationItemSelectedListener(this);
        navigationView.setCheckedItem(R.id.nav_settings);

        final Button btnClearCache = findViewById(R.id.btnClearCache);

        btnClearCache.setOnClickListener(v ->

        {
            btnClearCache.setEnabled(false);
            clearCache();
        });

    }

    //Clears App Cache
    private void clearCache() {
        FileUtils.deleteQuietly(this.getCacheDir());

        Context context = getApplicationContext();
        CharSequence text = "Your cache has been cleared.";
        int duration = Toast.LENGTH_LONG;
        //Display the Message.
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }

    //Enables the Back-button
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}
