
package com.ncl.team20.seatonvalley.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.*;

import com.ncl.team20.seatonvalley.ConnectionDetector;
import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.components.MainActivityComponent;


/**
 * MainActivity loads when the application is launching,it extends the abstract class Connection.
 *
 * @author Stelios Ioannou
 * @author Sam Clayton
 * @since 20/02/2018
 * Last Edit: 02/03/2018 by Stelios Ioannou
 */

public class MainActivity extends MainActivityComponent {

    //Creates a ConnectionDetector to determine connectivity.
    private final ConnectionDetector detector = new ConnectionDetector(MainActivity.this);

    //Creates UI elements.
    private ImageButton btnNews;
    private ImageButton btnTwitter;
    private ImageButton btnEvents;
    private ImageButton btnFind;
    private ImageButton btnContact;
    private ImageButton btnReport;
    private ImageButton btnCouncil;
    private ImageButton btnInfo;
    private ImageButton btnSettings;
    private RecyclerView recyclerView;
    private NavigationView navigationView;

    //Sets up the UI elements(sets Listeners on the buttons) and calls getContent(recyclerView) on Launch.

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(getString(R.string.home_screen_title));

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        //Gets UI elements
        btnNews = findViewById(R.id.btnNews);
        btnTwitter = findViewById(R.id.btnTwitter);
        btnEvents = findViewById(R.id.btnEvents);
        btnFind = findViewById(R.id.btnFind);
        btnContact = findViewById(R.id.btnContact);
        btnReport = findViewById(R.id.btnReport);
        btnCouncil = findViewById(R.id.btnCouncil);
        btnInfo = findViewById(R.id.btnInfo);
        btnSettings = findViewById(R.id.btnSettings);
        recyclerView = findViewById(R.id.recycler_view_latest);
        progressBar = findViewById(R.id.progressbar);
        progressBar.setVisibility(View.GONE);
        LinearLayoutManager mLayoutManager = new LinearLayoutManager(MainActivity.this, LinearLayoutManager.HORIZONTAL, false);
        recyclerView.setLayoutManager(mLayoutManager);

        //Gets the Main Activity Content
        getContent(recyclerView, detector, this);

        //Sets Button Listeners
        btnNews.setOnClickListener(v -> {
            btnNews.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), NewsActivity.class);
            startActivity(intent);
        });
        btnTwitter.setOnClickListener(v -> {
            btnTwitter.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), TwitterActivity.class);
            startActivity(intent);
        });
        btnEvents.setOnClickListener(v -> {
            btnEvents.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), EventsActivity.class);
            startActivity(intent);
        });
        btnFind.setOnClickListener(v -> {
            btnFind.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), FindActivity.class);
            startActivity(intent);
        });
        btnContact.setOnClickListener(v -> {
            btnContact.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), ContactActivity.class);
            startActivity(intent);
        });
        btnReport.setOnClickListener(v -> {
            btnReport.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), ReportActivity.class);
            startActivity(intent);
        });
        btnCouncil.setOnClickListener(v -> {
            btnCouncil.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), CouncilActivity.class);
            startActivity(intent);
        });
        btnInfo.setOnClickListener(v -> {
            btnInfo.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), InfoActivity.class);
            startActivity(intent);
        });
        btnSettings.setOnClickListener(v -> {
            btnSettings.setEnabled(false);
            Intent intent = new Intent(getApplicationContext(), SettingsActivity.class);
            startActivity(intent);
        });
    }

    /**
     * Restores the MainActivity to a navigable state and registers a connection receiver.
     * Last Edit: 2/03/2018 by Stelios Ioannou
     *
     * @author Stelios Ioannou
     * @since 20/02/2018
     */
    @Override
    protected void onResume() {
        super.onResume();
        //Re-enables the UI buttons when the MainActivity is resumed.
        btnNews.setEnabled(true);
        btnTwitter.setEnabled(true);
        btnEvents.setEnabled(true);
        btnFind.setEnabled(true);
        btnContact.setEnabled(true);
        btnReport.setEnabled(true);
        btnCouncil.setEnabled(true);
        btnInfo.setEnabled(true);
        btnSettings.setEnabled(true);
        //Sets the Correct Button in the Drawer
        navigationView.setCheckedItem(R.id.nav_home);
        //Clears adapter - Refreshes Content on Resume;
        //noinspection ConstantConditions
        if (list != null) {
            list.clear();
            adapter.notifyDataSetChanged();
        }
        getContent(recyclerView, detector, this);
    }
}