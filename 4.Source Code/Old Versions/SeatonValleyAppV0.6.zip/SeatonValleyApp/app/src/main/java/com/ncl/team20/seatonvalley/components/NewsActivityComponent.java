package com.ncl.team20.seatonvalley.components;

import android.content.Context;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.ncl.team20.seatonvalley.ConnectionDetector;
import com.ncl.team20.seatonvalley.adapters.PostsRecyclerViewAdapter;

/**
 * Gets the content of the News Activity by calling the appropriate methods.
 * Extends the New
 *
 * @author Stelios Ioannou
 * @since 01/03/2018
 * Edited on: 2/03/2018 by Stelios Ioannou
 */

public class NewsActivityComponent extends GetPosts {


    protected void getContent(RecyclerView recyclerView, ConnectionDetector detector, Context context) {
        if (detector.isInternetAvailable()) {
            progressBar.setVisibility(View.VISIBLE);
            getNews();
            adapter = new PostsRecyclerViewAdapter(list, context, 2);
            recyclerView.setAdapter(adapter);
        } else {
            getNews();
            adapter = new PostsRecyclerViewAdapter(list, context, 2);
            recyclerView.setAdapter(adapter);
            this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }
    }

    //Gets 100 Posts,With the Category of News
    private void getNews() {
        getPosts(100, "16", this);
    }

    //Enables the back-button
    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

}
