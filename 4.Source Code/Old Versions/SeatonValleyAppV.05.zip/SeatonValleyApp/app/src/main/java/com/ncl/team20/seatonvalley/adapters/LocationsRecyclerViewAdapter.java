package com.ncl.team20.seatonvalley.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.ncl.team20.seatonvalley.DisplayPlaceDetails;
import com.ncl.team20.seatonvalley.R;
import com.ncl.team20.seatonvalley.data.places.ModelPlace;

import java.util.ArrayList;


public class LocationsRecyclerViewAdapter extends RecyclerView.Adapter {

    private final ArrayList<ModelPlace> dataset;
    private final Context mContext;

    public LocationsRecyclerViewAdapter(ArrayList<ModelPlace> mlist, Context context) {
        this.dataset = mlist;
        this.mContext = context;
    }

    public static class ImageTypeViewHolder extends RecyclerView.ViewHolder {

        final TextView name;
        final TextView address;
        final TextView rating;
        final TextView open;

        final CardView card;

        public ImageTypeViewHolder(View itemView) {
            super(itemView);
            this.name = itemView.findViewById(R.id.name);
            this.address = itemView.findViewById(R.id.address);
            this.rating = itemView.findViewById(R.id.rating);
            this.card = itemView.findViewById(R.id.card);
            this.open = itemView.findViewById(R.id.open_now);
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View viewOne = LayoutInflater.from(parent.getContext()).inflate(R.layout.placedetails, parent, false);
        return new ImageTypeViewHolder(viewOne);
    }

    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        final ModelPlace object = dataset.get(position);

        ((ImageTypeViewHolder) holder).name.setText(object.name);
        ((ImageTypeViewHolder) holder).address.setText(object.vicinity);
        if (object.rating==null) {
            ((ImageTypeViewHolder) holder).rating.setText("Rating: Not Available.");
        } else {
            ((ImageTypeViewHolder) holder).rating.setText("Rating: " + String.valueOf(object.rating) + "/5.0");
        }

        if (!object.openWasNull) {
            if (object.openNow) {
                ((ImageTypeViewHolder) holder).open.setText("Open");
            }
            if (!object.openNow) {
                ((ImageTypeViewHolder) holder).open.setText("Closed");
                ((ImageTypeViewHolder) holder).open.setTextColor(Color.GRAY);

            } else {
                ((ImageTypeViewHolder) holder).open.setVisibility(View.GONE);

            }

        }

        ((ImageTypeViewHolder) holder).card.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, DisplayPlaceDetails.class);
            intent.putExtra("itemPosition", position);
            mContext.startActivity(intent);
        });

        ((ImageTypeViewHolder) holder).name.setOnClickListener(v -> {
            Intent intent = new Intent(mContext, DisplayPlaceDetails.class);
            intent.putExtra("itemPosition", position);
            mContext.startActivity(intent);
        });


    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }
}
