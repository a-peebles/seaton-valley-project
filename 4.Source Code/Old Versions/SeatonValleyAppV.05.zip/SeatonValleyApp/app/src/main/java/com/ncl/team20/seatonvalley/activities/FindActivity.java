package com.ncl.team20.seatonvalley.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

import com.ncl.team20.seatonvalley.R;

public class FindActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        //noinspection ConstantConditions
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Places");

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        final CardView cardRestaurants = findViewById(R.id.restaurants_card);
        final CardView cardCoffeeShops = findViewById(R.id.coffee_shops_card);
        final CardView cardMarkets = findViewById(R.id.markets_card);
        final CardView cardEntertainment = findViewById(R.id.entertainment_card);
        final CardView cardServices = findViewById(R.id.services_card);
        final CardView cardPetrolStations = findViewById(R.id.petrol_stations_card);



        cardRestaurants.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), PlacesActivity.class);
            intent.putExtra("title", "Restaurants");
            intent.putExtra("keyword", "");
            intent.putExtra("type", "restaurant");
            startActivity(intent);
        });
        cardCoffeeShops.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), PlacesActivity.class);
            intent.putExtra("title", "Coffee Shops");
            intent.putExtra("keyword", "");
            intent.putExtra("type", "cafe");
            startActivity(intent);

        });
        cardMarkets.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), PlacesActivity.class);
            intent.putExtra("title", "Shops");
            intent.putExtra("keyword", "");
            intent.putExtra("type", "store");
            startActivity(intent);
        });
        cardEntertainment.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), PlacesActivity.class);
            intent.putExtra("title", "Points of Interest");
            intent.putExtra("keyword", "");
            intent.putExtra("type", "point_of_interest");
            startActivity(intent);
        });
        cardServices.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), PlacesActivity.class);
            intent.putExtra("title", "ATM");
            intent.putExtra("keyword", "");
            intent.putExtra("type", "atm");
            startActivity(intent);
        });
        cardPetrolStations.setOnClickListener(v -> {
            Intent intent = new Intent(getApplicationContext(), PlacesActivity.class);
            intent.putExtra("title", "Petrol Stations");
            intent.putExtra("keyword", "");
            intent.putExtra("type", "gas_station");
            startActivity(intent);
        });

    }

    @Override
    public boolean onSupportNavigateUp(){
        finish();
        return true;
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
