package com.ncl.team20.seatonvalley.data;

import android.content.Context;

import com.ncl.team20.seatonvalley.ConnectionDetector;

import java.io.File;

import okhttp3.Cache;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;


public class ClientRequestBuilder {

    public static OkHttpClient getCacheClient(final Context context) {
        ConnectionDetector detector = new ConnectionDetector(context);

        Interceptor REWRITE_CACHE_CONTROL_INTERCEPTOR = chain -> {
            okhttp3.Response originalResponse = chain.proceed(chain.request());
            if (detector.isInternetAvailable()) {

                int maxAge = 300;
                return originalResponse.newBuilder()
                        .header("Cache-Control", "public, max-age=" + maxAge)
                        .build();
            } else {
                 int maxStale = 60 * 60 * 24 * 7;
                return originalResponse.newBuilder()
                        .header("Cache-Control", "public, only-if-cached, max-stale=" + maxStale)
                        .build();
            }
        };

        File httpCacheDirectory = new File(context.getCacheDir(), "cachedir");
        int size = 5 * 1024 * 1024;
        Cache cache = new Cache(httpCacheDirectory, size);

        return new OkHttpClient.Builder()
                .addNetworkInterceptor(REWRITE_CACHE_CONTROL_INTERCEPTOR)
                .cache(cache)
                .build();
    }


}
