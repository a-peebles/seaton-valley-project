package com.ncl.team20.seatonvalley.data.posts;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Post {

    @SerializedName("id")
    @Expose
    private Integer id;
    @SerializedName("title")
    @Expose
    private Title title;

    @SerializedName("excerpt")
    @Expose
    private Exerpt excerpt;
    @SerializedName("link")
    @Expose
    private String link;


    public Integer getId() {
        return id;
    }


    public Title getTitle() {
        return title;
    }

    public Exerpt getExcerpt() {
        return excerpt;
    }

    public String getLink() {
        return link;
    }

}








