package com.ncl.team20.seatonvalley;

import android.annotation.SuppressLint;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;

import com.ncl.team20.seatonvalley.activities.MainActivity;
import com.ncl.team20.seatonvalley.activities.PlacesActivity;
import com.ncl.team20.seatonvalley.activities.SettingsActivity;

public class DisplayPlaceDetails extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {


    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        Intent i = getIntent();
        @SuppressWarnings("ConstantConditions") int position = i.getExtras().getInt("itemPosition");

        String url = "https://www.google.com/maps/search/?api=1&query=";

        ConnectionDetector detector = new ConnectionDetector(DisplayPlaceDetails.this);

        if (detector.isInternetAvailable()) {
            url += PlacesActivity.mListPlace.getResults().get(position).getGeometry().getLocation().getLat();
            url += ",";
            url += PlacesActivity.mListPlace.getResults().get(position).getGeometry().getLocation().getLng();
            url += "&query_place_id=";
            url += PlacesActivity.mListPlace.getResults().get(position).getPlaceId();
            Intent browserIntent = new Intent(Intent.ACTION_VIEW,
                    Uri.parse(url));
            System.out.println(url);
            startActivity(browserIntent);
        } else {
            this.registerReceiver(this.mConnReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));
        }


    }

    private final BroadcastReceiver mConnReceiver = new BroadcastReceiver() {
        public void onReceive(Context context, Intent intent) {

            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo currentNetworkInfo = cm != null ? cm.getActiveNetworkInfo() : null;

            if (currentNetworkInfo != null && currentNetworkInfo.isConnectedOrConnecting()) {
                recreate();
                Toast.makeText(getApplicationContext(), "Connected", Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(getApplicationContext(), "No Internet Connection.\nMake sure your Wi-Fi or cellural data is turned on,then try again.",
                        Toast.LENGTH_LONG).show();
            }
        }
    };

    @Override
    protected void onResume() {
        super.onResume();
        IntentFilter intentFilter = new IntentFilter("com.agile.internetdemo.MainActivity");
        DisplayPlaceDetails.this.registerReceiver(mConnReceiver, intentFilter);
        onSupportNavigateUp();
        finish();
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("-", "onPause");
        DisplayPlaceDetails.this.unregisterReceiver(mConnReceiver);
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_home) {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        } else if (id == R.id.nav_settings) {
            Intent intent = new Intent(this, SettingsActivity.class);
            startActivity(intent);
        }

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
